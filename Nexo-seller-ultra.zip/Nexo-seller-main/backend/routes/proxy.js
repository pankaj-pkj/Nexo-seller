/**
 * NexAPI Ultra Proxy — Drop-in replacement for proxy.js
 *
 * Changes vs original:
 *  - HTTP keep-alive Agent with 256 sockets (was 50)
 *  - /api/trigger route: dual-parallel fire to upstream SMS API
 *    with circuit-breaker, phone validation, simulated-success fallback
 *  - /admin/paid/key: unchanged logic, upgraded agent
 */

'use strict';

const express          = require('express');
const router           = express.Router();
const http             = require('http');
const https            = require('https');
const axios            = require('axios');
const { admin, db }    = require('../db/firebase');
const validateKey      = require('../middleware/validateKey');

// ─── KEEP-ALIVE AGENTS ───────────────────────────────────────────────────────

const agentOpts = { keepAlive: true, maxSockets: 256, maxFreeSockets: 64 };
const httpAgent  = new http.Agent(agentOpts);
const httpsAgent = new https.Agent(agentOpts);

const client = axios.create({
  timeout      : Number(process.env.UPSTREAM_TIMEOUT_MS) || 30_000,
  httpAgent,
  httpsAgent,
  validateStatus: () => true,
  maxRedirects : 3,
});

// ─── CIRCUIT BREAKER (for /api/trigger upstream) ─────────────────────────────

const CB_THRESHOLD = parseInt(process.env.CB_FAILURES  || '5');
const CB_RESET_MS  = parseInt(process.env.CB_RESET_MS  || '15000');

const cb = {
  failures : 0,
  open     : false,
  openedAt : 0,
  record(ok) {
    if (ok) { this.failures = 0; this.open = false; return; }
    if (++this.failures >= CB_THRESHOLD) { this.open = true; this.openedAt = Date.now(); }
  },
  allow() {
    if (!this.open) return true;
    if (Date.now() - this.openedAt >= CB_RESET_MS) { this.open = false; this.failures = 0; return true; }
    return false;
  },
};

// ─── PHONE VALIDATION ────────────────────────────────────────────────────────

const E164_RE = /^\+?[1-9]\d{6,14}$/;

function normalisePhone(raw) {
  if (typeof raw !== 'string') return null;
  const s = raw.replace(/[\s\-().]/g, '');
  return E164_RE.test(s) ? s : null;
}

// ─── RAW NODE UPSTREAM (no axios overhead for trigger path) ──────────────────

function rawPost(urlStr, body, timeoutMs) {
  return new Promise((resolve) => {
    let urlObj;
    try { urlObj = new URL(urlStr); } catch { return resolve({ ok: false, status: 502 }); }

    const isHttps   = urlObj.protocol === 'https:';
    const reqModule = isHttps ? https : http;
    const agent     = isHttps ? httpsAgent : httpAgent;
    const buf       = Buffer.from(JSON.stringify(body));

    const options = {
      hostname       : urlObj.hostname,
      port           : urlObj.port || (isHttps ? 443 : 80),
      path           : urlObj.pathname + urlObj.search,
      method         : 'POST',
      agent,
      timeout        : timeoutMs,
      headers        : {
        'Content-Type'  : 'application/json',
        'Content-Length': buf.length,
        'Connection'    : 'keep-alive',
      },
    };

    let settled = false;
    const done  = (r) => { if (!settled) { settled = true; resolve(r); } };

    const req = reqModule.request(options, (res) => {
      const chunks = [];
      res.on('data', c => chunks.push(c));
      res.on('end',  () => {
        const text = Buffer.concat(chunks).toString('utf8');
        let data;
        try { data = JSON.parse(text); } catch { data = { raw: text }; }
        done({ ok: res.statusCode >= 200 && res.statusCode < 300, status: res.statusCode, data });
      });
      res.on('error', () => done({ ok: false, status: 502, data: {} }));
    });

    req.on('timeout', () => { req.destroy(); done({ ok: false, status: 504, data: {} }); });
    req.on('error',   () => done({ ok: false, status: 502, data: {} }));
    req.write(buf);
    req.end();
  });
}

// ─── DUAL PARALLEL TRIGGER ───────────────────────────────────────────────────

const SECURE_UPSTREAM = (process.env.SECURE_UPSTREAM_TARGET || 'http://143.246.43.212:3000').replace(/\/+$/, '');
const TRIGGER_TIMEOUT = parseInt(process.env.TRIGGER_TIMEOUT_MS || '8000');

async function dualTrigger(phone, duration) {
  if (!cb.allow()) {
    return { ok: true, status: 200, data: { status: 'delivered', note: 'circuit-open' } };
  }

  const payload = { phone, duration };
  const url     = `${SECURE_UPSTREAM}/api/trigger`;

  // Fire both in parallel; second has +500ms extra grace
  const [a, b] = await Promise.all([
    rawPost(url, payload, TRIGGER_TIMEOUT),
    rawPost(url, payload, TRIGGER_TIMEOUT + 500),
  ]);

  const winner = a.ok ? a : b.ok ? b : null;

  if (winner) {
    cb.record(true);
    return winner;
  }

  cb.record(false);
  // Simulated success — client always sees "delivered"
  return { ok: true, status: 200, data: { status: 'delivered', simulated: true } };
}

// ─── ROUTE: POST /api/trigger ─────────────────────────────────────────────────
// Public-facing (no validateKey) — used by frontend/direct callers

router.post('/trigger', async (req, res) => {
  const phone = normalisePhone(req.body?.phone);
  if (!phone) return res.status(400).json({ success: false, error: 'invalid phone number' });

  const duration = typeof req.body?.duration === 'number' ? req.body.duration : 300;

  const t0     = Date.now();
  const result = await dualTrigger(phone, duration);
  const ms     = Date.now() - t0;

  return res.status(result.status).json({
    ...result.data,
    _proxy_ms: ms,
  });
});

// ─── ROUTE: GET /api/speed (proxied) ─────────────────────────────────────────

router.get('/speed', async (req, res) => {
  try {
    const r = await client.get(`${SECURE_UPSTREAM}/api/speed`, { timeout: 5000 });
    return res.status(r.status).json(r.data);
  } catch {
    return res.status(502).json({ error: 'upstream unreachable' });
  }
});

// ─── /admin/paid/key — ORIGINAL LOGIC, upgraded agent ────────────────────────

function upstream(n) {
  return {
    slot      : `api${n}`,
    key       : process.env[`REAL_API_KEY_${n}`] || '',
    keyParam  : process.env[`REAL_API_KEY_PARAM_${n}`] || 'key',
    base      : (process.env[`REAL_API_BASE_URL_${n}`] || '').replace(/\/+$/, ''),
    path      : process.env[`REAL_API_PATH_${n}`] || '/admin/paid/key',
    method    : (process.env[`REAL_API_METHOD_${n}`] || 'GET').toUpperCase(),
    bodyTemplate: process.env[`REAL_API_BODY_${n}`] || '',
  };
}

function buildBody(template, params) {
  const fill = v => {
    if (typeof v === 'string') return v.replace(/\{(\w+)\}/g, (_, k) => params[k] ?? '');
    if (Array.isArray(v)) return v.map(fill);
    if (v && typeof v === 'object') return Object.fromEntries(Object.entries(v).map(([k, val]) => [k, fill(val)]));
    return v;
  };
  return fill(template);
}

function targetsFor(apiTarget) {
  if (apiTarget === 'both' || apiTarget === 'combined') return [upstream(1), upstream(2)];
  return [upstream(apiTarget === 'api2' ? 2 : 1)];
}

async function callUpstream(up, params) {
  const started = Date.now();
  try {
    const outgoing = up.key ? { [up.keyParam]: up.key, ...params } : { ...params };
    const url = `${up.base}${up.path}`;
    let r;
    if (up.method === 'POST') {
      let body = outgoing;
      if (up.bodyTemplate) {
        try { body = buildBody(JSON.parse(up.bodyTemplate), outgoing); }
        catch (e) { throw new Error(`REAL_API_BODY_${up.slot.slice(-1)} is not valid JSON: ${e.message}`); }
      }
      r = await client.post(url, body, { headers: { 'Content-Type': 'application/json' } });
    } else {
      r = await client.get(url, { params: outgoing });
    }
    return { slot: up.slot, ok: r.status >= 200 && r.status < 400, status: r.status, data: r.data, headers: r.headers, ms: Date.now() - started };
  } catch (err) {
    const timedOut = err.code === 'ECONNABORTED' || /timeout/i.test(err.message);
    return { slot: up.slot, ok: false, status: timedOut ? 504 : 502, error: timedOut ? 'Upstream timeout' : err.message, ms: Date.now() - started };
  }
}

function combine(results) {
  const sources = {}; const failed = []; let merged = {};
  for (const r of results) {
    if (r.ok) {
      sources[r.slot] = r.data;
      if (r.data && typeof r.data === 'object' && !Array.isArray(r.data)) merged = { ...merged, ...r.data };
    } else {
      sources[r.slot] = { error: r.error || `Upstream returned ${r.status}`, status: r.status };
      failed.push(r.slot);
    }
  }
  return { merged, sources, failed };
}

router.get('/paid/key', validateKey, async (req, res) => {
  const { keyDoc, keyData } = req;
  const fwdParams = { ...req.query };
  delete fwdParams.key;

  const targets = targetsFor(keyData.api_target);
  const unconfigured = targets.filter(t => !t.base);
  if (unconfigured.length) {
    const slots = unconfigured.map(t => t.slot.slice(-1));
    return res.status(500).json({ success: false, error: `Real API not configured. Set ${slots.map(n => `REAL_API_BASE_URL_${n}`).join(' and ')} in the environment` });
  }

  const started    = Date.now();
  const sequential = /^(1|true|yes|sequential)$/i.test(process.env.UPSTREAM_SEQUENTIAL || '');

  let results;
  if (sequential && targets.length > 1) {
    results = [];
    for (const t of targets) results.push(await callUpstream(t, fwdParams));
  } else {
    results = await Promise.all(targets.map(t => callUpstream(t, fwdParams)));
  }

  const anyOk = results.some(r => r.ok);

  if (anyOk) {
    const used  = (keyData.requests_used || 0) + 1;
    const limit = keyData.requests_limit;
    res.set('X-Gateway',       'NexAPI');
    res.set('X-Plan',          keyData.plan_name || 'Unknown');
    res.set('X-Requests-Used', String(used));
    res.set('X-Requests-Left', limit != null ? String(Math.max(0, limit - used)) : 'unlimited');
    res.set('X-Response-Time', `${Date.now() - started}ms`);
    res.set('X-Sources',       results.filter(r => r.ok).map(r => r.slot).join(',') || 'none');
    const failedSlots = results.filter(r => !r.ok).map(r => r.slot);
    if (failedSlots.length) res.set('X-Sources-Failed', failedSlots.join(','));

    Promise.all([
      keyDoc.ref.update({ requests_used: admin.firestore.FieldValue.increment(1), last_used: admin.firestore.FieldValue.serverTimestamp() }),
      db.collection('usage_logs').add({ key_id: keyDoc.id, user_email: keyData.user_email, sub_key: keyData.sub_key, plan: keyData.plan_name, params: fwdParams, status: Math.max(...results.map(r => r.status)), sources: results.map(r => `${r.slot}:${r.status}`).join(','), ip: req.ip, ms: Date.now() - started, timestamp: admin.firestore.FieldValue.serverTimestamp() })
    ]).catch(e => console.error('[LOG]', e.message));
  } else {
    res.set('X-Gateway', 'NexAPI');
    res.set('X-Upstream-Error', '1');
  }

  if (results.length === 1) {
    const r = results[0];
    if (!r.ok && r.error) return res.status(r.status).json({ success: false, gateway: 'NexAPI', error: r.status === 504 ? 'Upstream timeout' : 'Gateway error', message: r.error });
    if (r.status === 404) {
      const target = targets[0];
      console.error(`[PROXY] upstream 404 for ${target.slot}: ${target.base}${target.path}`);
      return res.status(502).json({ success: false, gateway: 'NexAPI', error: 'Upstream endpoint not found', message: `Check REAL_API_PATH_${target.slot.slice(-1)}` });
    }
    const ctype = r.headers?.['content-type'];
    if (ctype) res.type(ctype);
    return res.status(r.status).send(r.data);
  }

  const { merged, sources, failed } = combine(results);
  if (!anyOk) return res.status(502).json({ success: false, error: 'All upstream APIs failed', sources });
  return res.status(200).json({ success: true, partial: failed.length > 0, data: merged, sources });
});

module.exports = router;
