const { db } = require('../db/firebase');

async function expireKeys() {
  const now  = new Date();
  const snap = await db.collection('api_keys')
    .where('is_active', '==', true)
    .get();

  let expired = 0;
  const batch = db.batch();

  snap.docs.forEach(doc => {
    const data = doc.data();
    // Skip lifetime keys (no expires_at)
    if (!data.expires_at) return;

    const exp = data.expires_at.toDate
      ? data.expires_at.toDate()
      : new Date(data.expires_at);

    if (exp < now) {
      batch.update(doc.ref, { is_active: false });
      expired++;
    }
  });

  if (expired > 0) await batch.commit();
  return expired;
}

module.exports = { expireKeys };
