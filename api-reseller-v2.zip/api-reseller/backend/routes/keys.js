const express  = require('express');
const router   = express.Router();
const { db }   = require('../db/firebase');

// GET /api/key/:email
router.get('/:email', async (req, res) => {
  const email = decodeURIComponent(req.params.email).toLowerCase().trim();
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.status(400).json({ success: false, error: 'Invalid email' });

  try {
    const snap = await db.collection('api_keys')
      .where('user_email', '==', email)
      .orderBy('created_at', 'desc')
      .get();

    const now  = new Date();
    const keys = snap.docs.map(d => {
      const data = d.data();
      const exp  = data.expires_at
        ? (data.expires_at.toDate ? data.expires_at.toDate() : new Date(data.expires_at))
        : null;
      return {
        id:             d.id,
        ...data,
        expires_at:     exp ? exp.toISOString() : null,
        created_at:     data.created_at?.toDate?.()?.toISOString() || null,
        is_expired:     exp ? exp < now : false,
        days_left:      exp ? Math.max(0, Math.ceil((exp - now) / 86400000)) : null,
        is_lifetime:    !exp
      };
    });

    res.json({ success: true, keys });
  } catch (err) {
    console.error('[KEYS]', err.message);
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/key/check/:subkey
router.get('/check/:subkey', async (req, res) => {
  try {
    const snap = await db.collection('api_keys')
      .where('sub_key', '==', req.params.subkey)
      .limit(1).get();

    if (snap.empty) return res.status(404).json({ valid: false });
    const d   = snap.docs[0].data();
    const exp = d.expires_at?.toDate?.() || null;
    res.json({
      valid:          d.is_active && (exp ? exp > new Date() : true),
      plan:           d.plan_name,
      expires_at:     exp?.toISOString() || null,
      is_lifetime:    !exp,
      requests_used:  d.requests_used,
      requests_limit: d.requests_limit
    });
  } catch (err) {
    res.status(500).json({ valid: false, error: err.message });
  }
});

module.exports = router;
