const express      = require('express');
const router       = express.Router();
const { db, admin } = require('../db/firebase');

// ── Admin auth middleware ─────────────────────────────────────
function adminAuth(req, res, next) {
  const token = req.headers['x-admin-token'] || req.query.admin_token;
  if (!token || token !== process.env.ADMIN_SECRET)
    return res.status(403).json({ success: false, error: 'Unauthorized' });
  next();
}

// POST /api/admin/login — verify password
router.post('/login', (req, res) => {
  const { password } = req.body;
  if (password === process.env.ADMIN_SECRET)
    return res.json({ success: true, token: process.env.ADMIN_SECRET });
  res.status(403).json({ success: false, error: 'Wrong password' });
});

// GET /api/admin/stats
router.get('/stats', adminAuth, async (req, res) => {
  try {
    const [keysSnap, paymentsSnap, logsSnap] = await Promise.all([
      db.collection('api_keys').get(),
      db.collection('payments').get(),
      db.collection('usage_logs').orderBy('timestamp', 'desc').limit(1).get()
    ]);

    const now     = new Date();
    const keys    = keysSnap.docs.map(d => d.data());
    const pays    = paymentsSnap.docs.map(d => d.data());
    const paidPays = pays.filter(p => p.status === 'paid');

    const totalRevenue  = paidPays.reduce((s, p) => s + (p.amount || 0), 0);
    const activeKeys    = keys.filter(k => {
      if (!k.is_active) return false;
      if (!k.expires_at) return true;
      const exp = k.expires_at.toDate?.() || new Date(k.expires_at);
      return exp > now;
    }).length;
    const totalRequests = keys.reduce((s, k) => s + (k.requests_used || 0), 0);

    const planBreakdown = {};
    keys.forEach(k => {
      planBreakdown[k.plan_name] = (planBreakdown[k.plan_name] || 0) + 1;
    });

    res.json({
      success: true,
      total_revenue:  totalRevenue,
      total_payments: paymentsSnap.size,
      paid_payments:  paidPays.length,
      total_keys:     keysSnap.size,
      active_keys:    activeKeys,
      total_requests: totalRequests,
      plan_breakdown: planBreakdown
    });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/admin/keys?limit=50
router.get('/keys', adminAuth, async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 50;
    const snap  = await db.collection('api_keys')
      .orderBy('created_at', 'desc')
      .limit(limit)
      .get();

    const now  = new Date();
    const keys = snap.docs.map(d => {
      const data = d.data();
      const exp  = data.expires_at?.toDate?.() || null;
      return {
        id:            d.id,
        user_email:    data.user_email,
        sub_key:       data.sub_key,
        plan_name:     data.plan_name,
        plan_color:    data.plan_color,
        expires_at:    exp?.toISOString() || null,
        is_lifetime:   !exp,
        is_active:     data.is_active,
        is_expired:    exp ? exp < now : false,
        requests_used: data.requests_used || 0,
        requests_limit:data.requests_limit,
        payment_id:    data.payment_id,
        created_at:    data.created_at?.toDate?.()?.toISOString() || null
      };
    });

    res.json({ success: true, keys });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// GET /api/admin/payments?limit=50
router.get('/payments', adminAuth, async (req, res) => {
  try {
    const limit = parseInt(req.query.limit) || 50;
    const snap  = await db.collection('payments')
      .orderBy('created_at', 'desc')
      .limit(limit)
      .get();

    const pays = snap.docs.map(d => {
      const data = d.data();
      return {
        order_id:   data.order_id,
        user_email: data.user_email,
        plan_name:  data.plan_name,
        amount:     data.amount,
        currency:   data.currency,
        status:     data.status,
        created_at: data.created_at?.toDate?.()?.toISOString() || null,
        paid_at:    data.paid_at?.toDate?.()?.toISOString() || null
      };
    });

    res.json({ success: true, payments: pays });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/admin/keys/:id/deactivate
router.post('/keys/:id/deactivate', adminAuth, async (req, res) => {
  try {
    await db.collection('api_keys').doc(req.params.id).update({ is_active: false });
    res.json({ success: true, message: 'Key deactivated' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

// POST /api/admin/keys/:id/activate
router.post('/keys/:id/activate', adminAuth, async (req, res) => {
  try {
    await db.collection('api_keys').doc(req.params.id).update({ is_active: true });
    res.json({ success: true, message: 'Key activated' });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});

module.exports = router;
