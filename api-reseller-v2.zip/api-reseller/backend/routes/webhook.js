const express  = require('express');
const router   = express.Router();
const crypto   = require('crypto');
const { db, admin } = require('../db/firebase');
const { generateKey } = require('../utils/keygen');

function verifySign(body, apiKey) {
  const { sign, ...rest } = body;
  if (!sign) return false;
  const sorted = Object.keys(rest).sort()
    .reduce((a, k) => { a[k] = rest[k]; return a; }, {});
  const b64 = Buffer.from(JSON.stringify(sorted)).toString('base64');
  return crypto.createHash('md5').update(b64 + apiKey).digest('hex') === sign;
}

const isPaid = s => s === 1 || s === 'paid' || s === 'complete' || s === 'completed';

router.post('/', async (req, res) => {
  const data = req.body;
  console.log('[WEBHOOK]', JSON.stringify(data));

  if (!verifySign(data, process.env.HELEKET_API_KEY)) {
    console.warn('[WEBHOOK] Bad signature');
    return res.status(400).json({ error: 'Invalid signature' });
  }

  if (!isPaid(data.status))
    return res.json({ message: 'Not paid, ignored' });

  const orderId = data.order_id;
  if (!orderId) return res.status(400).json({ error: 'No order_id' });

  try {
    const payRef = db.collection('payments').doc(orderId);
    const payDoc = await payRef.get();

    if (!payDoc.exists) return res.status(404).json({ error: 'Order not found' });

    const order = payDoc.data();
    if (order.status === 'paid') return res.json({ message: 'Already processed' });

    // Fetch plan
    const planDoc = await db.collection('plans').doc(order.plan_id).get();
    const plan    = planDoc.data();

    // Calculate expiry (null = lifetime)
    let expiresAt = null;
    if (plan.duration_days !== null && plan.duration_days !== undefined) {
      expiresAt = new Date();
      expiresAt.setDate(expiresAt.getDate() + plan.duration_days);
    }

    const subKey  = generateKey();
    const keyData = {
      user_email:     order.user_email,
      sub_key:        subKey,
      plan_id:        order.plan_id,
      plan_name:      plan.name,
      plan_color:     plan.color || '#6366F1',
      api_target:     plan.api_target || 'api1',
      expires_at:     expiresAt,                  // null = lifetime
      requests_used:  0,
      requests_limit: plan.requests_limit,         // null = unlimited
      is_active:      true,
      payment_id:     orderId,
      created_at:     admin.firestore.FieldValue.serverTimestamp()
    };

    const batch = db.batch();
    batch.set(db.collection('api_keys').doc(), keyData);
    batch.update(payRef, {
      status:  'paid',
      paid_at: admin.firestore.FieldValue.serverTimestamp()
    });
    await batch.commit();

    const exp = expiresAt ? expiresAt.toDateString() : 'Never (Lifetime)';
    console.log(`[WEBHOOK] ✅ ${subKey} → ${order.user_email} | Plan: ${plan.name} | Expires: ${exp}`);
    res.json({ success: true });

  } catch (err) {
    console.error('[WEBHOOK]', err.message);
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
