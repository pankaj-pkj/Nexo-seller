const express      = require('express');
const router       = express.Router();
const axios        = require('axios');
const { admin, db } = require('../db/firebase');
const validateKey  = require('../middleware/validateKey');

/**
 * GET /admin/paid/key?key=USER_SUB_KEY&num=PHONE_NUMBER&...
 *
 * 1. validateKey middleware checks the sub-key
 * 2. Strip user's key, inject real API key
 * 3. Forward all other params (num, etc.) to the real API
 * 4. Increment usage counter + log in Firebase
 * 5. Return real API's response
 */
router.get('/paid/key', validateKey, async (req, res) => {
  const { keyDoc, keyData } = req;

  // Build forward params — remove sub-key, inject real key
  const fwdParams = { ...req.query };
  delete fwdParams.key;

  const useApi2    = keyData.api_target === 'api2';
  const realKey    = useApi2 ? process.env.REAL_API_KEY_2  : process.env.REAL_API_KEY_1;
  const realBase   = useApi2 ? process.env.REAL_API_BASE_URL_2 : process.env.REAL_API_BASE_URL_1;

  if (!realKey || !realBase) {
    return res.status(500).json({ success: false, error: 'Real API not configured. Set REAL_API_KEY_1 and REAL_API_BASE_URL_1 in .env' });
  }

  try {
    const upstream = await axios.get(`${realBase}/admin/paid/key`, {
      params:  { key: realKey, ...fwdParams },
      timeout: 30_000
    });

    // Increment usage + log (non-blocking)
    const logData = {
      key_id:     keyDoc.id,
      user_email: keyData.user_email,
      sub_key:    keyData.sub_key,
      plan:       keyData.plan_name,
      params:     fwdParams,
      status:     upstream.status,
      ip:         req.ip,
      timestamp:  admin.firestore.FieldValue.serverTimestamp()
    };

    Promise.all([
      keyDoc.ref.update({ requests_used: admin.firestore.FieldValue.increment(1), last_used: admin.firestore.FieldValue.serverTimestamp() }),
      db.collection('usage_logs').add(logData)
    ]).catch(e => console.error('[LOG]', e.message));

    // Gateway info headers
    res.set('X-Gateway',        'NexAPI');
    res.set('X-Plan',           keyData.plan_name);
    res.set('X-Requests-Used',  String((keyData.requests_used || 0) + 1));
    if (keyData.requests_limit)
      res.set('X-Requests-Left', String(keyData.requests_limit - keyData.requests_used - 1));

    return res.status(upstream.status).json(upstream.data);

  } catch (err) {
    if (err.response) return res.status(err.response.status).json(err.response.data);
    console.error('[PROXY]', err.message);
    return res.status(502).json({ success: false, error: 'Gateway error', message: err.message });
  }
});

module.exports = router;
