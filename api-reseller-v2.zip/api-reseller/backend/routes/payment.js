const express  = require('express');
const router   = express.Router();
const axios    = require('axios');
const crypto   = require('crypto');
const { v4: uuid } = require('uuid');
const { db, admin } = require('../db/firebase');

function heleket_sign(params, apiKey) {
  const sorted = Object.keys(params).sort()
    .reduce((a, k) => { a[k] = params[k]; return a; }, {});
  const b64 = Buffer.from(JSON.stringify(sorted)).toString('base64');
  return crypto.createHash('md5').update(b64 + apiKey).digest('hex');
}

// POST /api/payment/create
router.post('/create', async (req, res) => {
  const { plan_id, email } = req.body;

  if (!plan_id || !email)
    return res.status(400).json({ success: false, error: 'plan_id and email required' });
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email))
    return res.status(400).json({ success: false, error: 'Invalid email' });

  try {
    const planDoc = await db.collection('plans').doc(plan_id).get();
    if (!planDoc.exists)
      return res.status(404).json({ success: false, error: 'Plan not found' });

    const plan    = planDoc.data();
    const orderId = `NX${uuid().replace(/-/g, '').slice(0, 14).toUpperCase()}`;
    const returnUrl = `${process.env.HELEKET_RETURN}?order_id=${orderId}&email=${encodeURIComponent(email)}`;

    const body = {
      amount:       plan.price_usd.toString(),
      currency:     'USDT',
      order_id:     orderId,
      url_return:   returnUrl,
      url_callback: `${process.env.BACKEND_URL}/api/webhook`,
      comment:      `NexAPI ${plan.name} Plan`
    };

    const sign = heleket_sign(body, process.env.HELEKET_API_KEY);

    const hRes = await axios.post(
      `${process.env.HELEKET_BASE_URL}/v1/payment`,
      body,
      { headers: { merchant: process.env.HELEKET_MERCHANT, sign, 'Content-Type': 'application/json' }, timeout: 15000 }
    );

    if (hRes.data.state !== 0)
      throw new Error(hRes.data.message || 'Heleket error');

    // Save payment record
    await db.collection('payments').doc(orderId).set({
      order_id:           orderId,
      user_email:         email.toLowerCase(),
      plan_id:            plan_id,
      plan_name:          plan.name,
      amount:             plan.price_usd,
      currency:           'USDT',
      status:             'pending',
      heleket_payment_id: hRes.data.result.uuid,
      created_at:         admin.firestore.FieldValue.serverTimestamp()
    });

    console.log(`[PAYMENT] ${orderId} | ${email} | ${plan.name} | $${plan.price_usd}`);
    res.json({ success: true, payment_url: hRes.data.result.url, order_id: orderId });

  } catch (err) {
    const msg = err.response?.data?.message || err.message;
    console.error('[PAYMENT]', msg);
    res.status(500).json({ success: false, error: msg });
  }
});

module.exports = router;
