const { db } = require('../db/firebase');

/**
 * Middleware: validates ?key= or X-API-Key header.
 * Attaches req.keyDoc and req.keyData on success.
 */
async function validateKey(req, res, next) {
  const key =
    req.query.key ||
    req.headers['x-api-key'] ||
    (req.headers['authorization'] || '').replace('Bearer ', '').trim();

  if (!key) {
    return res.status(401).json({
      success: false,
      error: 'API key required',
      hint: 'Add ?key=YOUR_KEY to your request'
    });
  }

  try {
    const snap = await db.collection('api_keys')
      .where('sub_key', '==', key)
      .where('is_active', '==', true)
      .limit(1)
      .get();

    if (snap.empty) {
      return res.status(401).json({ success: false, error: 'Invalid API key' });
    }

    const keyDoc  = snap.docs[0];
    const keyData = keyDoc.data();

    // Expiry check (null expires_at = Lifetime plan)
    if (keyData.expires_at) {
      const exp = keyData.expires_at.toDate
        ? keyData.expires_at.toDate()
        : new Date(keyData.expires_at);

      if (exp < new Date()) {
        await keyDoc.ref.update({ is_active: false });
        return res.status(401).json({
          success: false,
          error:   'API key expired',
          plan:    keyData.plan_name,
          expired_at: exp.toISOString()
        });
      }
    }

    // Request limit (null = unlimited)
    if (keyData.requests_limit !== null &&
        keyData.requests_limit !== undefined &&
        keyData.requests_used >= keyData.requests_limit) {
      return res.status(429).json({
        success: false,
        error:   'Request limit reached for this billing period',
        used:    keyData.requests_used,
        limit:   keyData.requests_limit,
        plan:    keyData.plan_name
      });
    }

    req.keyDoc  = keyDoc;
    req.keyData = keyData;
    next();

  } catch (err) {
    console.error('[validateKey]', err.message);
    res.status(500).json({ success: false, error: 'Key validation error' });
  }
}

module.exports = validateKey;
