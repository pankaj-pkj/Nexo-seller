require('dotenv').config();
const express = require('express');
const cors    = require('cors');
const cron    = require('node-cron');

const app = express();
app.use(cors({ origin: '*' }));
app.use(express.json());

// ── Routes ────────────────────────────────────────────────────
app.use('/api/plans',   require('./routes/plans'));
app.use('/api/payment', require('./routes/payment'));
app.use('/api/webhook', require('./routes/webhook'));
app.use('/api/key',     require('./routes/keys'));
app.use('/api/admin',   require('./routes/admin'));
app.use('/admin',       require('./routes/proxy'));   // /admin/paid/key

// ── Health (also used by auto-ping) ──────────────────────────
app.get('/health', (req, res) => res.json({
  status:    'online',
  gateway:   'NexAPI v2',
  timestamp: new Date().toISOString()
}));

// ── Cron: expire keys daily at midnight ──────────────────────
cron.schedule('0 0 * * *', async () => {
  try {
    const { expireKeys } = require('./utils/expiry');
    const n = await expireKeys();
    console.log(`[CRON] Expired ${n} keys`);
  } catch (e) { console.error('[CRON]', e.message); }
});

// ── Auto-ping Render (prevents free-tier sleep) ───────────────
require('./utils/ping').startAutoPing();

// ── Start ─────────────────────────────────────────────────────
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`\n⚡ NexAPI Gateway v2 on port ${PORT}`);
  console.log(`   Health  → http://localhost:${PORT}/health`);
  console.log(`   Gateway → http://localhost:${PORT}/admin/paid/key?key=NK-XXX&num=91XXXXXXXXXX\n`);
});
